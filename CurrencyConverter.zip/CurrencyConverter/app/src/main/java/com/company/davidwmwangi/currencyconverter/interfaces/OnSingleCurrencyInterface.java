package com.company.davidwmwangi.currencyconverter.interfaces;

/**
 * Created by David W. Mwangi on 01/11/2017.
 */

public interface OnSingleCurrencyInterface {

    public void openSingleCardActivity(long card_id, String selected_currency);
}
